package b8;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ManagerCard managerCard = new ManagerCard();
        while (true) {
            // show input for user choise
            // 1 to insert
            // 2 to remove => input id. output boolean
            // 4 get salary => input id. output double
            // 5 exit => return

        }
    }
}
