# oop_employee_management



## Getting started

Bản code prototype cho bài 13 trong bộ bài tập tổng hợp tại [Deft blog](https://shareprogramming.net/tong-hop-bai-tap-lap-trinh-huong-doi-tuong-trong-java/)

Các bạn có thể dựa vào đây, để lấy ý tưởng và triển khai bài hoàn chỉnh.


