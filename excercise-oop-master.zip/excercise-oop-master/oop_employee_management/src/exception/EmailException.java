package exception;

public class EmailException extends Exception {
}
