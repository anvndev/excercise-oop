package exception;

public class FullNameException extends Exception {

    public FullNameException(String message) {
        super(message);
    }
}
