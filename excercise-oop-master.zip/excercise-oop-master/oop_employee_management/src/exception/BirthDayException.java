package exception;

public class BirthDayException extends Exception {
    public BirthDayException(String message) {
        super(message);
    }
}
